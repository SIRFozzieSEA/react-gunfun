import React from 'react';

const UserProfile = ({ user }) => {
    return (
        <div className="user-profile">
            <div className="userprofile_column">
                <h2>{user.name}</h2>
                <p>{user.email}</p>
            </div>
        </div>
    );
};

export default UserProfile;
