import React from "react";

const Bobo = () => {
    return (
        <div className="Bobo">
            <div>
                bobo!
            </div>
        </div>
    );
};

export default Bobo;
