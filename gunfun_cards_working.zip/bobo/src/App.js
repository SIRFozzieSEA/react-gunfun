import React, { useState } from 'react';
import './App.css';
import Bobo from './Bobo';
import UserProfilePage from "./UserProfilePage";

function App() {

    const [currentContent, setCurrentContent] = useState('Home screen');

    const handleHomeClick = () => {
        setCurrentContent(<Bobo />); // Set currentContent to the Bobo component
    };

    const handleUserClick = () => {
        setCurrentContent(<UserProfilePage/>); // Set currentContent to the Bobo component
    };



    return (
        <div className="container">
            <div className="menu">
                <ul>
                    <li onClick={handleHomeClick}>Home</li>
                    <li onClick={handleUserClick}>Users</li>
                </ul>
            </div>
            <div className="content">
                {currentContent}
            </div>
        </div>
    );
}

export default App;
