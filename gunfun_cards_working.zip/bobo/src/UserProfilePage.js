import React from "react";
import UserProfile from "./UserProfile";

const UserProfilePage = () => {

    const user = {
        name: 'John Doe',
        email: 'john.doe@example.com',
        // Add more user details here
    };
    const userTwo = {
        name: 'John Doe',
        email: 'john.doe@example.com',
        // Add more user details here
    };
    const userThree = {
        name: 'John Doe',
        email: 'john.doe@example.com',
        // Add more user details here
    };
    const userFour = {
        name: 'John Doe',
        email: 'john.doe@example.com',
        // Add more user details here
    };

    return (
        <div className="content">
            <UserProfile user={user}/><UserProfile user={userTwo}/><UserProfile user={userThree}/><UserProfile
            user={userFour}/>
        </div>
    );
};

export default UserProfilePage;
